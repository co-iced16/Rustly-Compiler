#ifndef AST_H
#define AST_H

#include "token.h"
#include <memory>
#include <vector>
#include <string>

// 前向声明
class ASTNode;
class Expression;
class Statement;
class Declaration;
class Type;
class Block;

// ============ 基类 ============

class ASTNode {
public:
    virtual ~ASTNode() = default;
    virtual void print(int indent = 0) const = 0;
};

// ============ 类型 ============

class Type : public ASTNode {
public:
    virtual ~Type() = default;
};

class I32Type : public Type {
public:
    void print(int indent = 0) const override;
};

// 6.2, 6.3 引用类型
class RefType : public Type {
public:
    bool isMut;  // true 表示 &mut T, false 表示 &T
    std::unique_ptr<Type> innerType;

    RefType(bool mut, std::unique_ptr<Type> inner)
        : isMut(mut), innerType(std::move(inner)) {}
    void print(int indent = 0) const override;
};

// 8.1 数组类型
class ArrayType : public Type {
public:
    std::unique_ptr<Type> elementType;
    int size;

    ArrayType(std::unique_ptr<Type> elemType, int sz)
        : elementType(std::move(elemType)), size(sz) {}
    void print(int indent = 0) const override;
};

// 9.1 元组类型
class TupleType : public Type {
public:
    std::vector<std::unique_ptr<Type>> elementTypes;

    explicit TupleType(std::vector<std::unique_ptr<Type>> types)
        : elementTypes(std::move(types)) {}
    void print(int indent = 0) const override;
};

// ============ 表达式 ============

class Expression : public ASTNode {
public:
    virtual ~Expression() = default;
};

class NumberLiteral : public Expression {
public:
    int value;

    explicit NumberLiteral(int val) : value(val) {}
    void print(int indent = 0) const override;
};

class Identifier : public Expression {
public:
    std::string name;

    explicit Identifier(const std::string& n) : name(n) {}
    void print(int indent = 0) const override;
};

class BinaryExpr : public Expression {
public:
    std::unique_ptr<Expression> left;
    TokenType op;
    std::unique_ptr<Expression> right;

    BinaryExpr(std::unique_ptr<Expression> l, TokenType o, std::unique_ptr<Expression> r)
        : left(std::move(l)), op(o), right(std::move(r)) {}
    void print(int indent = 0) const override;
};

class CallExpr : public Expression {
public:
    std::string function;
    std::vector<std::unique_ptr<Expression>> args;

    CallExpr(const std::string& func, std::vector<std::unique_ptr<Expression>> arguments)
        : function(func), args(std::move(arguments)) {}
    void print(int indent = 0) const override;
};

// 一元表达式（取引用、解引用）
class UnaryExpr : public Expression {
public:
    TokenType op;  // AMPERSAND (&) 或 STAR (*)
    bool isMut;    // 仅用于 & 运算符，表示 &mut
    std::unique_ptr<Expression> operand;

    UnaryExpr(TokenType o, std::unique_ptr<Expression> expr, bool mut = false)
        : op(o), isMut(mut), operand(std::move(expr)) {}
    void print(int indent = 0) const override;
};

// 8.2 数组字面量
class ArrayLiteral : public Expression {
public:
    std::vector<std::unique_ptr<Expression>> elements;

    explicit ArrayLiteral(std::vector<std::unique_ptr<Expression>> elems)
        : elements(std::move(elems)) {}
    void print(int indent = 0) const override;
};

// 8.3 数组索引
class IndexExpr : public Expression {
public:
    std::unique_ptr<Expression> array;
    std::unique_ptr<Expression> index;

    IndexExpr(std::unique_ptr<Expression> arr, std::unique_ptr<Expression> idx)
        : array(std::move(arr)), index(std::move(idx)) {}
    void print(int indent = 0) const override;
};

// 9.2 元组字面量
class TupleLiteral : public Expression {
public:
    std::vector<std::unique_ptr<Expression>> elements;

    explicit TupleLiteral(std::vector<std::unique_ptr<Expression>> elems)
        : elements(std::move(elems)) {}
    void print(int indent = 0) const override;
};

// 9.3 元组索引（成员访问）
class TupleIndexExpr : public Expression {
public:
    std::unique_ptr<Expression> tuple;
    int index;

    TupleIndexExpr(std::unique_ptr<Expression> tup, int idx)
        : tuple(std::move(tup)), index(idx) {}
    void print(int indent = 0) const override;
};

// 7.1 块表达式
class BlockExpr : public Expression {
public:
    std::unique_ptr<Block> block;

    explicit BlockExpr(std::unique_ptr<Block> blk)
        : block(std::move(blk)) {}
    void print(int indent = 0) const override;
};

// 7.3 if 表达式
class IfExpr : public Expression {
public:
    std::unique_ptr<Expression> condition;
    std::unique_ptr<Block> thenBlock;
    std::unique_ptr<Block> elseBlock;  // 必须有 else 分支

    IfExpr(std::unique_ptr<Expression> cond,
           std::unique_ptr<Block> thenB,
           std::unique_ptr<Block> elseB)
        : condition(std::move(cond)), thenBlock(std::move(thenB)),
          elseBlock(std::move(elseB)) {}
    void print(int indent = 0) const override;
};

// 7.4 loop 表达式
class LoopExpr : public Expression {
public:
    std::unique_ptr<Block> body;

    explicit LoopExpr(std::unique_ptr<Block> b)
        : body(std::move(b)) {}
    void print(int indent = 0) const override;
};

// ============ 语句 ============

class Statement : public ASTNode {
public:
    virtual ~Statement() = default;
};

class Block : public ASTNode {
public:
    std::vector<std::unique_ptr<Statement>> statements;
    std::unique_ptr<Expression> tailExpr;  // 7.0 块尾表达式（可选）

    void print(int indent = 0) const override;
};

class EmptyStmt : public Statement {
public:
    void print(int indent = 0) const override;
};

class ExprStmt : public Statement {
public:
    std::unique_ptr<Expression> expr;

    explicit ExprStmt(std::unique_ptr<Expression> e) : expr(std::move(e)) {}
    void print(int indent = 0) const override;
};

class ReturnStmt : public Statement {
public:
    std::unique_ptr<Expression> value; // nullptr 表示 return;

    explicit ReturnStmt(std::unique_ptr<Expression> val = nullptr)
        : value(std::move(val)) {}
    void print(int indent = 0) const override;
};

class LetStmt : public Statement {
public:
    bool isMut;
    std::string name;
    std::unique_ptr<Type> type; // nullptr 表示类型推导
    std::unique_ptr<Expression> init; // nullptr 表示未初始化

    LetStmt(bool mut, const std::string& n,
            std::unique_ptr<Type> t = nullptr,
            std::unique_ptr<Expression> i = nullptr)
        : isMut(mut), name(n), type(std::move(t)), init(std::move(i)) {}
    void print(int indent = 0) const override;
};

class AssignStmt : public Statement {
public:
    std::string target; // 简化版：只支持标识符作为左值
    std::unique_ptr<Expression> value;

    AssignStmt(const std::string& t, std::unique_ptr<Expression> v)
        : target(t), value(std::move(v)) {}
    void print(int indent = 0) const override;
};

class IfStmt : public Statement {
public:
    std::unique_ptr<Expression> condition;
    std::unique_ptr<Block> thenBlock;
    std::unique_ptr<Block> elseBlock; // nullptr 表示没有 else

    IfStmt(std::unique_ptr<Expression> cond,
           std::unique_ptr<Block> thenB,
           std::unique_ptr<Block> elseB = nullptr)
        : condition(std::move(cond)), thenBlock(std::move(thenB)),
          elseBlock(std::move(elseB)) {}
    void print(int indent = 0) const override;
};

class WhileStmt : public Statement {
public:
    std::unique_ptr<Expression> condition;
    std::unique_ptr<Block> body;

    WhileStmt(std::unique_ptr<Expression> cond, std::unique_ptr<Block> b)
        : condition(std::move(cond)), body(std::move(b)) {}
    void print(int indent = 0) const override;
};

// 5.2 for 循环
class ForStmt : public Statement {
public:
    bool isMut;
    std::string varName;
    std::unique_ptr<Expression> start;
    std::unique_ptr<Expression> end;
    std::unique_ptr<Block> body;

    ForStmt(bool mut, const std::string& var,
            std::unique_ptr<Expression> s,
            std::unique_ptr<Expression> e,
            std::unique_ptr<Block> b)
        : isMut(mut), varName(var), start(std::move(s)),
          end(std::move(e)), body(std::move(b)) {}
    void print(int indent = 0) const override;
};

// 5.3 loop 循环
class LoopStmt : public Statement {
public:
    std::unique_ptr<Block> body;

    explicit LoopStmt(std::unique_ptr<Block> b) : body(std::move(b)) {}
    void print(int indent = 0) const override;
};

// 5.4 break 语句
class BreakStmt : public Statement {
public:
    std::unique_ptr<Expression> value;  // 7.4 可选的 break 表达式

    explicit BreakStmt(std::unique_ptr<Expression> v = nullptr)
        : value(std::move(v)) {}
    void print(int indent = 0) const override;
};

// 5.4 continue 语句
class ContinueStmt : public Statement {
public:
    void print(int indent = 0) const override;
};

// ============ 声明 ============

class Declaration : public ASTNode {
public:
    virtual ~Declaration() = default;
};

struct Parameter {
    bool isMut;
    std::string name;
    std::unique_ptr<Type> type;

    Parameter(bool mut, const std::string& n, std::unique_ptr<Type> t)
        : isMut(mut), name(n), type(std::move(t)) {}
};

class FunctionDecl : public Declaration {
public:
    std::string name;
    std::vector<Parameter> params;
    std::unique_ptr<Type> returnType; // nullptr 表示无返回值
    std::unique_ptr<Block> body;

    FunctionDecl(const std::string& n,
                 std::vector<Parameter> p,
                 std::unique_ptr<Type> ret,
                 std::unique_ptr<Block> b)
        : name(n), params(std::move(p)), returnType(std::move(ret)),
          body(std::move(b)) {}
    void print(int indent = 0) const override;
};

// ============ 程序 ============

class Program : public ASTNode {
public:
    std::vector<std::unique_ptr<Declaration>> declarations;

    void print(int indent = 0) const override;
};

#endif // AST_H
